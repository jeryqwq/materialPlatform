
  <template>
    <div style="text-align: center">
      <img src="./assets/Vue.png" style="width: 100px"/>
      <h2>HELLO Vue in VIS-CODE-EDITOR</h2>
      <Main />
    </div>
  </template>
  <script>
    import './a/b.js'
    import Main from './vue3.vue'
    console.log(echarts, '------lib ecahrt')
    export default {
      components: { Main }
    }
  </script>
  <style scoped lang="scss">
    img{
      margin: 20px
    }
    h2{
      color: red
    }
  </style>
   
   